﻿namespace SimpleArithmeticCalculator.Interfaces
{
    interface ICalculator
    {
    }
}
