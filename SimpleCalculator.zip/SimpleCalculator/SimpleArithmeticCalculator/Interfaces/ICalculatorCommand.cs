﻿namespace SimpleArithmeticCalculator.Interfaces
{
    public interface ICalculatorCommand
    {
        double Calculate(double firstValue, double secondValue);
    }
}
