﻿namespace SimpleArithmeticCalculator.Enums
{
    public enum CommandType
    {

        Add = 1,
        Subtract = 2,
        Multiply = 3,
        Divide = 4

    }
}
